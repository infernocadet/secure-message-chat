# dictionary to map users and user sessions
user_sessions = {}